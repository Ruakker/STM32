#include "stm32f10x.h"

int main() {
    RCC->APB2ENR |= 1 << 3;  // 使能
    GPIOB->CRL |= 7;  // 此处模式选择开漏输出（不知道为啥写 0b0111 会报错，可能是 C 的版本问题）
    GPIOB->ODR |= 0;  // 设 PB1 引脚为低电平
    // GPIOB->ODR |= 1 << 0;  // 若设 PB1 引脚为高阻态（1），则灯灭

    while (1) {
        
    }
}
